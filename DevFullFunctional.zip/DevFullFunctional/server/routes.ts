import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertIssueSchema, insertLabUsageLogSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Issues routes
  app.get("/api/issues", async (req, res) => {
    try {
      const issues = await storage.getIssues();
      res.json(issues);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch issues" });
    }
  });

  app.post("/api/issues", async (req, res) => {
    try {
      const issueData = insertIssueSchema.parse(req.body);
      const issue = await storage.createIssue(issueData);
      res.status(201).json(issue);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid issue data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create issue" });
      }
    }
  });

  app.patch("/api/issues/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const issue = await storage.updateIssue(id, updates);
      if (!issue) {
        return res.status(404).json({ message: "Issue not found" });
      }
      res.json(issue);
    } catch (error) {
      res.status(500).json({ message: "Failed to update issue" });
    }
  });

  app.delete("/api/issues/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteIssue(id);
      if (!deleted) {
        return res.status(404).json({ message: "Issue not found" });
      }
      res.json({ message: "Issue deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete issue" });
    }
  });

  // Lab usage logs routes
  app.get("/api/lab-usage-logs", async (req, res) => {
    try {
      const logs = await storage.getLabUsageLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch lab usage logs" });
    }
  });

  app.post("/api/lab-usage-logs", async (req, res) => {
    try {
      const logData = insertLabUsageLogSchema.parse(req.body);
      const log = await storage.createLabUsageLog(logData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid log data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create lab usage log" });
      }
    }
  });

  app.delete("/api/lab-usage-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteLabUsageLog(id);
      if (!deleted) {
        return res.status(404).json({ message: "Lab usage log not found" });
      }
      res.json({ message: "Lab usage log deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete lab usage log" });
    }
  });

  app.delete("/api/lab-usage-logs", async (req, res) => {
    try {
      await storage.deleteAllLabUsageLogs();
      res.json({ message: "All lab usage logs deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete all lab usage logs" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
