import { users, issues, labUsageLogs, type User, type InsertUser, type Issue, type InsertIssue, type LabUsageLog, type InsertLabUsageLog } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Issue methods
  getIssues(): Promise<Issue[]>;
  getIssue(id: number): Promise<Issue | undefined>;
  createIssue(issue: InsertIssue): Promise<Issue>;
  updateIssue(id: number, updates: Partial<Issue>): Promise<Issue | undefined>;
  deleteIssue(id: number): Promise<boolean>;
  
  // Lab usage log methods
  getLabUsageLogs(): Promise<LabUsageLog[]>;
  getLabUsageLog(id: number): Promise<LabUsageLog | undefined>;
  createLabUsageLog(log: InsertLabUsageLog): Promise<LabUsageLog>;
  deleteLabUsageLog(id: number): Promise<boolean>;
  deleteAllLabUsageLogs(): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private issues: Map<number, Issue>;
  private labUsageLogs: Map<number, LabUsageLog>;
  private currentUserId: number;
  private currentIssueId: number;
  private currentLogId: number;

  constructor() {
    this.users = new Map();
    this.issues = new Map();
    this.labUsageLogs = new Map();
    this.currentUserId = 1;
    this.currentIssueId = 1;
    this.currentLogId = 1;
    
    // Add sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample users
    const sampleUsers = [
      { username: "student1", password: "pass123", role: "student" },
      { username: "tech1", password: "pass123", role: "technician" }
    ];
    
    sampleUsers.forEach(user => {
      const id = this.currentUserId++;
      this.users.set(id, { ...user, id });
    });

    // Sample issues
    const sampleIssues = [
      {
        studentName: "John Doe",
        rollNumber: "CS21001",
        labNumber: "PL-1",
        systemId: "PC-15",
        issueType: "Hardware",
        priority: "Critical",
        description: "Computer won't boot up, screen remains black",
        status: "open",
        reportedBy: "anonymous",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
        updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
      {
        studentName: "Jane Smith",
        rollNumber: "CS21002",
        labNumber: "PL-2",
        systemId: "PC-08",
        issueType: "Software",
        priority: "High",
        description: "Visual Studio Code crashes when opening large files",
        status: "in_progress",
        reportedBy: "anonymous",
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
        updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000) // 12 hours ago
      },
      {
        studentName: "Mike Johnson",
        rollNumber: "CS21003",
        labNumber: "PL-3",
        systemId: "PC-22",
        issueType: "Network",
        priority: "Medium",
        description: "Internet connection is very slow, affecting online resources",
        status: "resolved",
        reportedBy: "anonymous",
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
        updatedAt: new Date(Date.now() - 6 * 60 * 60 * 1000) // 6 hours ago
      },
      {
        studentName: "Sarah Wilson",
        rollNumber: "CS21004",
        labNumber: "PL-1",
        systemId: "PC-05",
        issueType: "Hardware",
        priority: "Low",
        description: "Keyboard spacebar key is sticky and needs replacement",
        status: "open",
        reportedBy: "anonymous",
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        updatedAt: new Date(Date.now() - 4 * 60 * 60 * 1000)
      }
    ];

    sampleIssues.forEach(issue => {
      const id = this.currentIssueId++;
      this.issues.set(id, { ...issue, id });
    });

    // Sample lab usage logs
    const sampleLogs = [
      {
        studentName: "Alice Brown",
        rollNumber: "CS21005",
        year: "2nd Year",
        systemNumber: "PC-10",
        subject: "Data Structures",
        lab: "PL-1",
        contactNumber: "+1234567890",
        email: "alice.brown@university.edu",
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
      },
      {
        studentName: "Bob Davis",
        rollNumber: "CS21006",
        year: "3rd Year",
        systemNumber: "PC-18",
        subject: "Operating Systems",
        lab: "PL-2",
        contactNumber: "+1234567891",
        email: "bob.davis@university.edu",
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000) // 5 hours ago
      },
      {
        studentName: "Carol White",
        rollNumber: "CS21007",
        year: "1st Year",
        systemNumber: "PC-03",
        subject: "Programming Fundamentals",
        lab: "PL-3",
        contactNumber: "+1234567892",
        email: "carol.white@university.edu",
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) // 1 day ago
      },
      {
        studentName: "David Lee",
        rollNumber: "CS21008",
        year: "4th Year",
        systemNumber: "PC-27",
        subject: "Software Engineering",
        lab: "PL-4",
        contactNumber: "+1234567893",
        email: "david.lee@university.edu",
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000) // 3 hours ago
      },
      {
        studentName: "Emma Wilson",
        rollNumber: "CS21009",
        year: "2nd Year",
        systemNumber: "PC-12",
        subject: "Database Systems",
        lab: "PL-1",
        contactNumber: "+1234567894",
        email: "emma.wilson@university.edu",
        createdAt: new Date(Date.now() - 30 * 60 * 1000) // 30 minutes ago
      }
    ];

    sampleLogs.forEach(log => {
      const id = this.currentLogId++;
      this.labUsageLogs.set(id, { ...log, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, role: insertUser.role || "student" };
    this.users.set(id, user);
    return user;
  }

  async getIssues(): Promise<Issue[]> {
    return Array.from(this.issues.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getIssue(id: number): Promise<Issue | undefined> {
    return this.issues.get(id);
  }

  async createIssue(insertIssue: InsertIssue): Promise<Issue> {
    const id = this.currentIssueId++;
    const now = new Date();
    const issue: Issue = { 
      ...insertIssue, 
      id, 
      status: insertIssue.status || "open",
      createdAt: now,
      updatedAt: now
    };
    this.issues.set(id, issue);
    return issue;
  }

  async updateIssue(id: number, updates: Partial<Issue>): Promise<Issue | undefined> {
    const issue = this.issues.get(id);
    if (!issue) return undefined;
    
    const updatedIssue = { ...issue, ...updates, updatedAt: new Date() };
    this.issues.set(id, updatedIssue);
    return updatedIssue;
  }

  async deleteIssue(id: number): Promise<boolean> {
    return this.issues.delete(id);
  }

  async getLabUsageLogs(): Promise<LabUsageLog[]> {
    return Array.from(this.labUsageLogs.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getLabUsageLog(id: number): Promise<LabUsageLog | undefined> {
    return this.labUsageLogs.get(id);
  }

  async createLabUsageLog(insertLog: InsertLabUsageLog): Promise<LabUsageLog> {
    const id = this.currentLogId++;
    const log: LabUsageLog = { 
      ...insertLog, 
      id, 
      createdAt: new Date()
    };
    this.labUsageLogs.set(id, log);
    return log;
  }

  async deleteLabUsageLog(id: number): Promise<boolean> {
    return this.labUsageLogs.delete(id);
  }

  async deleteAllLabUsageLogs(): Promise<boolean> {
    this.labUsageLogs.clear();
    return true;
  }
}

export const storage = new MemStorage();
