import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("student"), // student or technician
});

export const issues = pgTable("issues", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  rollNumber: text("roll_number").notNull(),
  labNumber: text("lab_number").notNull(),
  systemId: text("system_id").notNull(),
  issueType: text("issue_type").notNull(),
  priority: text("priority").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("open"),
  reportedBy: text("reported_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const labUsageLogs = pgTable("lab_usage_logs", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  rollNumber: text("roll_number").notNull(),
  year: text("year").notNull(),
  systemNumber: text("system_number").notNull(),
  subject: text("subject").notNull(),
  lab: text("lab").notNull(),
  contactNumber: text("contact_number").notNull(),
  email: text("email").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertIssueSchema = createInsertSchema(issues).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLabUsageLogSchema = createInsertSchema(labUsageLogs).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Issue = typeof issues.$inferSelect;
export type InsertIssue = z.infer<typeof insertIssueSchema>;
export type LabUsageLog = typeof labUsageLogs.$inferSelect;
export type InsertLabUsageLog = z.infer<typeof insertLabUsageLogSchema>;
