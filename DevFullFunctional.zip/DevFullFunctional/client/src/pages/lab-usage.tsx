import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Modal } from "@/components/modal";
import { apiRequest } from "@/lib/queryClient";
import { insertLabUsageLogSchema, type LabUsageLog } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

const usageFormSchema = insertLabUsageLogSchema;
type UsageFormData = z.infer<typeof usageFormSchema>;

export default function LabUsage() {
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [modalType, setModalType] = useState<"success" | "error">("success");
  const { userRole } = useAuth();
  const queryClient = useQueryClient();

  const { data: logs = [], isLoading } = useQuery<LabUsageLog[]>({
    queryKey: ["/api/lab-usage-logs"],
  });

  const form = useForm<UsageFormData>({
    resolver: zodResolver(usageFormSchema),
    defaultValues: {
      studentName: "",
      rollNumber: "",
      year: "",
      systemNumber: "",
      subject: "",
      lab: "",
      contactNumber: "",
      email: "",
    },
  });

  const createLogMutation = useMutation({
    mutationFn: async (data: UsageFormData) => {
      const response = await apiRequest("POST", "/api/lab-usage-logs", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lab-usage-logs"] });
      setModalMessage("Lab usage logged successfully!");
      setModalType("success");
      setShowModal(true);
      form.reset();
    },
    onError: (error) => {
      setModalMessage("Failed to log lab usage. Please try again.");
      setModalType("error");
      setShowModal(true);
    },
  });

  const deleteLogMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/lab-usage-logs/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lab-usage-logs"] });
      setModalMessage("Lab usage log deleted successfully!");
      setModalType("success");
      setShowModal(true);
    },
    onError: (error) => {
      setModalMessage("Failed to delete lab usage log. Please try again.");
      setModalType("error");
      setShowModal(true);
    },
  });

  const deleteAllLogsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", "/api/lab-usage-logs");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lab-usage-logs"] });
      setModalMessage("All lab usage logs deleted successfully!");
      setModalType("success");
      setShowModal(true);
    },
    onError: (error) => {
      setModalMessage("Failed to delete lab usage logs. Please try again.");
      setModalType("error");
      setShowModal(true);
    },
  });

  const onSubmit = (data: UsageFormData) => {
    createLogMutation.mutate(data);
  };

  const handleDeleteLog = (id: number) => {
    if (confirm("Are you sure you want to delete this lab usage log? This action cannot be undone.")) {
      deleteLogMutation.mutate(id);
    }
  };

  const handleDeleteAll = () => {
    if (confirm("Are you sure you want to delete all lab usage logs? This action cannot be undone.")) {
      deleteAllLogsMutation.mutate();
    }
  };

  const exportToCSV = () => {
    if (logs.length === 0) {
      setModalMessage("No data to export!");
      setModalType("error");
      setShowModal(true);
      return;
    }

    const headers = ["Student Name", "Roll Number", "Year", "System Number", "Subject", "Lab", "Contact Number", "Email", "Date"];
    const csvContent = [
      headers.join(","),
      ...logs.map(log => [
        log.studentName,
        log.rollNumber,
        log.year,
        log.systemNumber,
        log.subject,
        log.lab,
        log.contactNumber,
        log.email,
        log.createdAt ? new Date(log.createdAt).toLocaleDateString() : ""
      ].join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "lab_usage_logs.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Lab Usage Log</CardTitle>
          <p className="text-text-secondary">
            Track your lab session and record usage details
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="studentName">Student Name</Label>
                <Input
                  id="studentName"
                  {...form.register("studentName")}
                  className="mt-1"
                />
                {form.formState.errors.studentName && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.studentName.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="rollNumber">Roll Number</Label>
                <Input
                  id="rollNumber"
                  {...form.register("rollNumber")}
                  className="mt-1"
                />
                {form.formState.errors.rollNumber && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.rollNumber.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="year">Year</Label>
                <Select onValueChange={(value) => form.setValue("year", value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select Year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1st Year">1st Year</SelectItem>
                    <SelectItem value="2nd Year">2nd Year</SelectItem>
                    <SelectItem value="3rd Year">3rd Year</SelectItem>
                    <SelectItem value="4th Year">4th Year</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.year && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.year.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="systemNumber">System Number</Label>
                <Input
                  id="systemNumber"
                  {...form.register("systemNumber")}
                  placeholder="e.g., PC-15"
                  className="mt-1"
                />
                {form.formState.errors.systemNumber && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.systemNumber.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  {...form.register("subject")}
                  placeholder="e.g., Data Structures"
                  className="mt-1"
                />
                {form.formState.errors.subject && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.subject.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="lab">Lab</Label>
                <Select onValueChange={(value) => form.setValue("lab", value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select Lab" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PL-1">PL-1</SelectItem>
                    <SelectItem value="PL-2">PL-2</SelectItem>
                    <SelectItem value="PL-3">PL-3</SelectItem>
                    <SelectItem value="PL-4">PL-4</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.lab && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.lab.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="contactNumber">Contact Number</Label>
                <Input
                  id="contactNumber"
                  {...form.register("contactNumber")}
                  className="mt-1"
                />
                {form.formState.errors.contactNumber && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.contactNumber.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...form.register("email")}
                  className="mt-1"
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.email.message}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => form.reset()}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createLogMutation.isPending}
                className="bg-primary text-white hover:bg-primary-dark"
              >
                {createLogMutation.isPending ? "Logging..." : "Log Usage"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Lab Usage Logs</CardTitle>
            <div className="flex items-center space-x-3">
              <Button
                onClick={exportToCSV}
                variant="outline"
                className="bg-purple-600 text-white hover:bg-purple-700"
              >
                Export to CSV
              </Button>
              {userRole === "technician" && (
                <Button
                  onClick={handleDeleteAll}
                  variant="destructive"
                  disabled={deleteAllLogsMutation.isPending}
                >
                  {deleteAllLogsMutation.isPending ? "Deleting..." : "Delete All"}
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading logs...</div>
          ) : logs.length > 0 ? (
            <div className="space-y-4">
              {logs.map((log) => (
                <div key={log.id} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-text-primary">
                        {log.studentName} ({log.rollNumber})
                      </div>
                      <div className="text-sm text-text-secondary">
                        {log.systemNumber} • {log.subject} • {log.lab}
                      </div>
                      <div className="text-sm text-text-secondary">
                        {log.contactNumber} • {log.email}
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="text-sm text-text-secondary">
                        {log.createdAt ? new Date(log.createdAt).toLocaleDateString() : 'Today'}
                      </div>
                      {userRole === "technician" && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteLog(log.id)}
                          disabled={deleteLogMutation.isPending}
                        >
                          {deleteLogMutation.isPending ? "Deleting..." : "Delete"}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-text-secondary">
              No lab usage logs found
            </div>
          )}
        </CardContent>
      </Card>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={modalType === "success" ? "Success!" : "Error"}
        type={modalType}
      >
        {modalMessage}
      </Modal>
    </div>
  );
}
