import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";

export default function SystemMonitoring() {
  const { userRole } = useAuth();
  const [systemStatus, setSystemStatus] = useState({
    labComputers: [
      { id: "PC-001", lab: "Lab 1", status: "online", cpu: 45, memory: 67, disk: 23 },
      { id: "PC-002", lab: "Lab 1", status: "online", cpu: 32, memory: 54, disk: 18 },
      { id: "PC-003", lab: "Lab 1", status: "maintenance", cpu: 0, memory: 0, disk: 0 },
      { id: "PC-004", lab: "Lab 2", status: "online", cpu: 78, memory: 89, disk: 34 },
      { id: "PC-005", lab: "Lab 2", status: "offline", cpu: 0, memory: 0, disk: 0 },
      { id: "PC-006", lab: "Lab 2", status: "online", cpu: 56, memory: 43, disk: 67 },
      { id: "PC-007", lab: "Lab 3", status: "online", cpu: 23, memory: 78, disk: 45 },
      { id: "PC-008", lab: "Lab 3", status: "online", cpu: 67, memory: 34, disk: 89 },
    ],
    networkStatus: {
      mainRouter: "online",
      labSwitches: { lab1: "online", lab2: "online", lab3: "warning" },
      internetSpeed: { download: 95.2, upload: 87.3 },
      latency: 12
    },
    environmentalSensors: {
      temperature: 22.5,
      humidity: 45,
      airQuality: "good"
    }
  });

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setSystemStatus(prev => ({
        ...prev,
        labComputers: prev.labComputers.map(pc => ({
          ...pc,
          cpu: pc.status === "online" ? Math.max(10, Math.min(90, pc.cpu + (Math.random() - 0.5) * 10)) : 0,
          memory: pc.status === "online" ? Math.max(10, Math.min(95, pc.memory + (Math.random() - 0.5) * 8)) : 0,
          disk: pc.status === "online" ? Math.max(5, Math.min(85, pc.disk + (Math.random() - 0.5) * 5)) : 0
        }))
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  if (userRole !== "technician") {
    return (
      <div className="text-center py-8">
        <p className="text-text-secondary">Access denied. Technician role required.</p>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "bg-green-100 text-green-800";
      case "offline": return "bg-red-100 text-red-800";
      case "maintenance": return "bg-yellow-100 text-yellow-800";
      case "warning": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPerformanceColor = (value: number) => {
    if (value < 30) return "bg-green-500";
    if (value < 70) return "bg-yellow-500";
    return "bg-red-500";
  };

  const onlineComputers = systemStatus.labComputers.filter(pc => pc.status === "online").length;
  const totalComputers = systemStatus.labComputers.length;
  const systemUptime = "99.2%";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">System Monitoring</h1>
          <p className="text-text-secondary">Real-time lab system performance and status</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-green-50 text-green-700">
            <i className="fas fa-circle text-green-500 mr-1"></i>
            System Online
          </Badge>
          <Button variant="outline" size="sm">
            <i className="fas fa-sync mr-2"></i>
            Refresh
          </Button>
        </div>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-desktop text-green-600 text-xl"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">
                  {onlineComputers}/{totalComputers}
                </div>
                <div className="text-sm text-text-secondary">Computers Online</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-network-wired text-blue-600 text-xl"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">{systemStatus.networkStatus.latency}ms</div>
                <div className="text-sm text-text-secondary">Network Latency</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-thermometer-half text-purple-600 text-xl"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">{systemStatus.environmentalSensors.temperature}°C</div>
                <div className="text-sm text-text-secondary">Temperature</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-line text-orange-600 text-xl"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">{systemUptime}</div>
                <div className="text-sm text-text-secondary">System Uptime</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Computer Status Grid */}
      <Card>
        <CardHeader>
          <CardTitle>Lab Computer Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {systemStatus.labComputers.map((computer) => (
              <div key={computer.id} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="font-medium text-text-primary">{computer.id}</div>
                  <Badge className={getStatusColor(computer.status)}>
                    {computer.status}
                  </Badge>
                </div>
                <div className="text-sm text-text-secondary mb-3">{computer.lab}</div>
                
                {computer.status === "online" && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>CPU</span>
                      <span>{computer.cpu}%</span>
                    </div>
                    <Progress value={computer.cpu} className="h-2" />
                    
                    <div className="flex items-center justify-between text-sm">
                      <span>Memory</span>
                      <span>{computer.memory}%</span>
                    </div>
                    <Progress value={computer.memory} className="h-2" />
                    
                    <div className="flex items-center justify-between text-sm">
                      <span>Disk</span>
                      <span>{computer.disk}%</span>
                    </div>
                    <Progress value={computer.disk} className="h-2" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Network Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Network Infrastructure</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Main Router</span>
              <Badge className={getStatusColor(systemStatus.networkStatus.mainRouter)}>
                {systemStatus.networkStatus.mainRouter}
              </Badge>
            </div>
            
            <div className="space-y-2">
              <span className="text-sm font-medium">Lab Switches</span>
              {Object.entries(systemStatus.networkStatus.labSwitches).map(([lab, status]) => (
                <div key={lab} className="flex items-center justify-between ml-4">
                  <span className="text-sm text-text-secondary capitalize">{lab}</span>
                  <Badge className={getStatusColor(status)}>
                    {status}
                  </Badge>
                </div>
              ))}
            </div>
            
            <div className="pt-4 border-t">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Internet Speed</span>
                <div className="text-sm text-text-secondary">
                  ↓ {systemStatus.networkStatus.internetSpeed.download} Mbps / 
                  ↑ {systemStatus.networkStatus.internetSpeed.upload} Mbps
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Environmental Monitoring</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Temperature</span>
              <div className="flex items-center space-x-2">
                <i className="fas fa-thermometer-half text-blue-500"></i>
                <span className="text-sm">{systemStatus.environmentalSensors.temperature}°C</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Humidity</span>
              <div className="flex items-center space-x-2">
                <i className="fas fa-tint text-blue-500"></i>
                <span className="text-sm">{systemStatus.environmentalSensors.humidity}%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Air Quality</span>
              <Badge className="bg-green-100 text-green-800">
                {systemStatus.environmentalSensors.airQuality}
              </Badge>
            </div>
            
            <div className="pt-4 border-t">
              <div className="text-sm text-text-secondary">
                Last updated: {new Date().toLocaleTimeString()}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>System Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="flex items-center space-x-3">
                <i className="fas fa-exclamation-triangle text-yellow-600"></i>
                <div>
                  <div className="font-medium text-yellow-800">Lab 3 Switch Warning</div>
                  <div className="text-sm text-yellow-700">Network switch experiencing intermittent connectivity</div>
                </div>
              </div>
              <Button size="sm" variant="outline">
                Investigate
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
              <div className="flex items-center space-x-3">
                <i className="fas fa-desktop text-orange-600"></i>
                <div>
                  <div className="font-medium text-orange-800">PC-003 Maintenance Required</div>
                  <div className="text-sm text-orange-700">System has been offline for scheduled maintenance</div>
                </div>
              </div>
              <Button size="sm" variant="outline">
                Check Status
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}