import { useQuery } from "@tanstack/react-query";
import { StatsCard } from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Issue, LabUsageLog } from "@shared/schema";

export default function Dashboard() {
  const { data: issues = [], isLoading: issuesLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: labLogs = [], isLoading: logsLoading } = useQuery<LabUsageLog[]>({
    queryKey: ["/api/lab-usage-logs"],
  });

  if (issuesLoading || logsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-text-secondary">Loading dashboard...</div>
      </div>
    );
  }

  const openIssues = issues.filter(issue => issue.status === "open").length;
  const resolvedIssues = issues.filter(issue => issue.status === "resolved").length;
  const criticalIssues = issues.filter(issue => issue.priority === "Critical").length;

  const recentIssues = issues.slice(0, 3);
  const recentLogs = labLogs.slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Open Issues"
          value={openIssues}
          icon="fas fa-exclamation-triangle"
          color="red"
        />
        <StatsCard
          title="Resolved"
          value={resolvedIssues}
          icon="fas fa-check-circle"
          color="green"
        />
        <StatsCard
          title="Critical Issues"
          value={criticalIssues}
          icon="fas fa-exclamation-circle"
          color="red"
        />
        <StatsCard
          title="Total Students"
          value={new Set(labLogs.map(log => log.rollNumber)).size}
          icon="fas fa-users"
          color="blue"
        />
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentIssues.length > 0 ? (
                recentIssues.map((issue) => (
                  <div key={issue.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-desktop text-red-600"></i>
                      </div>
                      <div className="ml-3">
                        <div className="text-sm font-medium text-text-primary">
                          {issue.systemId} {issue.issueType}
                        </div>
                        <div className="text-xs text-text-secondary">
                          {issue.labNumber} • {issue.studentName}
                        </div>
                      </div>
                    </div>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      issue.priority === 'Critical' 
                        ? 'bg-red-100 text-red-800'
                        : issue.priority === 'High'
                        ? 'bg-orange-100 text-orange-800'
                        : issue.priority === 'Medium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {issue.priority}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-text-secondary">
                  No issues reported yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Lab Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentLogs.length > 0 ? (
                recentLogs.map((log) => (
                  <div key={log.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-user text-green-600"></i>
                      </div>
                      <div className="ml-3">
                        <div className="text-sm font-medium text-text-primary">
                          {log.studentName} ({log.rollNumber})
                        </div>
                        <div className="text-xs text-text-secondary">
                          {log.systemNumber} • {log.subject}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-text-secondary">
                      {log.createdAt ? new Date(log.createdAt).toLocaleDateString() : 'Today'}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-text-secondary">
                  No lab usage logged yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
