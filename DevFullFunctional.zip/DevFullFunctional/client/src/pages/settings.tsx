import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { userRole, toggleRole } = useAuth();
  const { toast } = useToast();
  
  const [settings, setSettings] = useState({
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      criticalAlerts: true,
      weeklyReports: false,
      maintenanceUpdates: true
    },
    preferences: {
      theme: "light",
      language: "en",
      timezone: "UTC-5",
      dateFormat: "MM/DD/YYYY",
      autoRefresh: true
    },
    profile: {
      name: userRole === "student" ? "Student User" : "Technician User",
      email: userRole === "student" ? "student@university.edu" : "technician@university.edu",
      phone: "",
      department: "Computer Science"
    }
  });

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const handleExportData = () => {
    toast({
      title: "Data Export Started",
      description: "Your data export will be ready shortly. Check your email for the download link.",
    });
  };

  const updateSetting = (category: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [key]: value
      }
    }));
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-text-primary">Settings</h1>
        <p className="text-text-secondary">
          Manage your account preferences and system settings
        </p>
      </div>

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={settings.profile.name}
                onChange={(e) => updateSetting("profile", "name", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={settings.profile.email}
                onChange={(e) => updateSetting("profile", "email", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={settings.profile.phone}
                onChange={(e) => updateSetting("profile", "phone", e.target.value)}
                placeholder="+1-555-0123"
              />
            </div>
            <div>
              <Label htmlFor="department">Department</Label>
              <Select value={settings.profile.department} onValueChange={(value) => updateSetting("profile", "department", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Computer Science">Computer Science</SelectItem>
                  <SelectItem value="Information Technology">Information Technology</SelectItem>
                  <SelectItem value="Engineering">Engineering</SelectItem>
                  <SelectItem value="Mathematics">Mathematics</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Role Management */}
      <Card>
        <CardHeader>
          <CardTitle>Role Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <h4 className="font-medium text-text-primary">Current Role</h4>
              <p className="text-sm text-text-secondary capitalize">
                You are currently logged in as a {userRole}
              </p>
            </div>
            <Button onClick={toggleRole} variant="outline">
              Switch to {userRole === "student" ? "Technician" : "Student"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="email-notifications">Email Notifications</Label>
              <p className="text-sm text-text-secondary">Receive notifications via email</p>
            </div>
            <Switch
              id="email-notifications"
              checked={settings.notifications.emailNotifications}
              onCheckedChange={(checked) => updateSetting("notifications", "emailNotifications", checked)}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="push-notifications">Push Notifications</Label>
              <p className="text-sm text-text-secondary">Browser push notifications</p>
            </div>
            <Switch
              id="push-notifications"
              checked={settings.notifications.pushNotifications}
              onCheckedChange={(checked) => updateSetting("notifications", "pushNotifications", checked)}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="critical-alerts">Critical Issue Alerts</Label>
              <p className="text-sm text-text-secondary">Immediate alerts for critical issues</p>
            </div>
            <Switch
              id="critical-alerts"
              checked={settings.notifications.criticalAlerts}
              onCheckedChange={(checked) => updateSetting("notifications", "criticalAlerts", checked)}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="weekly-reports">Weekly Reports</Label>
              <p className="text-sm text-text-secondary">Weekly summary of lab activities</p>
            </div>
            <Switch
              id="weekly-reports"
              checked={settings.notifications.weeklyReports}
              onCheckedChange={(checked) => updateSetting("notifications", "weeklyReports", checked)}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="maintenance-updates">Maintenance Updates</Label>
              <p className="text-sm text-text-secondary">System maintenance notifications</p>
            </div>
            <Switch
              id="maintenance-updates"
              checked={settings.notifications.maintenanceUpdates}
              onCheckedChange={(checked) => updateSetting("notifications", "maintenanceUpdates", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* App Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Application Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="theme">Theme</Label>
              <Select value={settings.preferences.theme} onValueChange={(value) => updateSetting("preferences", "theme", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="auto">Auto</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="language">Language</Label>
              <Select value={settings.preferences.language} onValueChange={(value) => updateSetting("preferences", "language", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Spanish</SelectItem>
                  <SelectItem value="fr">French</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="timezone">Timezone</Label>
              <Select value={settings.preferences.timezone} onValueChange={(value) => updateSetting("preferences", "timezone", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UTC-5">Eastern Time (UTC-5)</SelectItem>
                  <SelectItem value="UTC-6">Central Time (UTC-6)</SelectItem>
                  <SelectItem value="UTC-7">Mountain Time (UTC-7)</SelectItem>
                  <SelectItem value="UTC-8">Pacific Time (UTC-8)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="date-format">Date Format</Label>
              <Select value={settings.preferences.dateFormat} onValueChange={(value) => updateSetting("preferences", "dateFormat", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                  <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                  <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="auto-refresh">Auto Refresh Data</Label>
              <p className="text-sm text-text-secondary">Automatically refresh data every 30 seconds</p>
            </div>
            <Switch
              id="auto-refresh"
              checked={settings.preferences.autoRefresh}
              onCheckedChange={(checked) => updateSetting("preferences", "autoRefresh", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
            <div>
              <h4 className="font-medium text-text-primary">Export Data</h4>
              <p className="text-sm text-text-secondary">
                Download your data in CSV format
              </p>
            </div>
            <Button onClick={handleExportData} variant="outline">
              <i className="fas fa-download mr-2"></i>
              Export Data
            </Button>
          </div>
          
          {userRole === "technician" && (
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div>
                <h4 className="font-medium text-text-primary">Backup System</h4>
                <p className="text-sm text-text-secondary">
                  Last backup: Today at 3:00 AM
                </p>
              </div>
              <Button variant="outline">
                <i className="fas fa-shield-alt mr-2"></i>
                View Backups
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} className="bg-primary hover:bg-primary-dark">
          <i className="fas fa-save mr-2"></i>
          Save Settings
        </Button>
      </div>
    </div>
  );
}