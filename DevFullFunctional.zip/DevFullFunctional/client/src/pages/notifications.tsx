import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import type { Issue } from "@shared/schema";

export default function Notifications() {
  const { userRole } = useAuth();
  const [filter, setFilter] = useState<string>("all");
  
  const { data: issues = [], isLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  // Generate notifications based on issues and user role
  const generateNotifications = () => {
    const notifications = [];
    const now = new Date();

    issues.forEach(issue => {
      const createdAt = new Date(issue.createdAt || now);
      const hoursOld = Math.floor((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60));

      // Critical issue alerts
      if (issue.priority === "Critical" && issue.status === "open") {
        notifications.push({
          id: `critical-${issue.id}`,
          type: "critical",
          title: "Critical Issue Requires Immediate Attention",
          message: `${issue.issueType} reported in ${issue.labNumber} (${issue.systemId}) - ${hoursOld}h ago`,
          time: createdAt,
          priority: "high",
          issueId: issue.id,
          actionRequired: userRole === "technician"
        });
      }

      // Overdue issues (open for more than 24 hours)
      if (issue.status === "open" && hoursOld > 24) {
        notifications.push({
          id: `overdue-${issue.id}`,
          type: "overdue",
          title: "Issue Overdue for Resolution",
          message: `${issue.issueType} in ${issue.labNumber} has been open for ${Math.floor(hoursOld / 24)} days`,
          time: createdAt,
          priority: "medium",
          issueId: issue.id,
          actionRequired: userRole === "technician"
        });
      }

      // High priority issues for technicians
      if (issue.priority === "High" && issue.status === "open" && userRole === "technician") {
        notifications.push({
          id: `high-priority-${issue.id}`,
          type: "high-priority",
          title: "High Priority Issue Pending",
          message: `${issue.studentName} reported ${issue.issueType} in ${issue.labNumber}`,
          time: createdAt,
          priority: "medium",
          issueId: issue.id,
          actionRequired: true
        });
      }

      // Recently resolved issues (for students)
      if (issue.status === "resolved" && userRole === "student") {
        const updatedAt = new Date(issue.updatedAt || now);
        const hoursResolved = Math.floor((now.getTime() - updatedAt.getTime()) / (1000 * 60 * 60));
        
        if (hoursResolved < 24) {
          notifications.push({
            id: `resolved-${issue.id}`,
            type: "resolved",
            title: "Issue Resolved",
            message: `Your ${issue.issueType} issue in ${issue.labNumber} has been resolved`,
            time: updatedAt,
            priority: "low",
            issueId: issue.id,
            actionRequired: false
          });
        }
      }
    });

    // System maintenance notifications
    notifications.push({
      id: "maintenance-scheduled",
      type: "maintenance",
      title: "Scheduled Maintenance",
      message: "Lab maintenance scheduled for this weekend (Saturday 2:00 AM - 6:00 AM)",
      time: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      priority: "low",
      actionRequired: false
    });

    // Equipment low stock alert (for technicians)
    if (userRole === "technician") {
      notifications.push({
        id: "inventory-low",
        type: "inventory",
        title: "Low Inventory Alert",
        message: "Mouse supplies running low in storage room - 3 units remaining",
        time: new Date(now.getTime() - 2 * 60 * 60 * 1000), // 2 hours ago
        priority: "medium",
        actionRequired: true
      });
    }

    return notifications.sort((a, b) => b.time.getTime() - a.time.getTime());
  };

  const notifications = generateNotifications();

  const filteredNotifications = notifications.filter(notification => {
    if (filter === "all") return true;
    if (filter === "action-required") return notification.actionRequired;
    return notification.priority === filter;
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "critical": return "fas fa-exclamation-triangle text-red-500";
      case "overdue": return "fas fa-clock text-orange-500";
      case "high-priority": return "fas fa-arrow-up text-yellow-500";
      case "resolved": return "fas fa-check-circle text-green-500";
      case "maintenance": return "fas fa-wrench text-blue-500";
      case "inventory": return "fas fa-boxes text-purple-500";
      default: return "fas fa-bell text-gray-500";
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return "Yesterday";
    const days = Math.floor(diffInHours / 24);
    return `${days} days ago`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-text-secondary">Loading notifications...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Notifications</h1>
          <p className="text-text-secondary">
            Stay updated with lab activities and important alerts
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter notifications" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Notifications</SelectItem>
              <SelectItem value="action-required">Action Required</SelectItem>
              <SelectItem value="high">High Priority</SelectItem>
              <SelectItem value="medium">Medium Priority</SelectItem>
              <SelectItem value="low">Low Priority</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Notification Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-exclamation-triangle text-red-600"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">
                  {notifications.filter(n => n.priority === "high").length}
                </div>
                <div className="text-sm text-text-secondary">High Priority</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-bell text-yellow-600"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">
                  {notifications.filter(n => n.actionRequired).length}
                </div>
                <div className="text-sm text-text-secondary">Action Required</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-check-circle text-green-600"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">
                  {notifications.filter(n => n.type === "resolved").length}
                </div>
                <div className="text-sm text-text-secondary">Resolved Today</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-list text-blue-600"></i>
              </div>
              <div>
                <div className="text-2xl font-bold text-text-primary">
                  {notifications.length}
                </div>
                <div className="text-sm text-text-secondary">Total Notifications</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notifications List */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Notifications</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredNotifications.length > 0 ? (
            <div className="space-y-4">
              {filteredNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 rounded-lg border ${
                    notification.actionRequired ? 'border-yellow-200 bg-yellow-50' : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <i className={`${getTypeIcon(notification.type)} text-lg mt-1`}></i>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-text-primary">{notification.title}</h4>
                          <Badge className={getPriorityColor(notification.priority)}>
                            {notification.priority}
                          </Badge>
                          {notification.actionRequired && (
                            <Badge variant="outline" className="border-yellow-400 text-yellow-700">
                              Action Required
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-text-secondary mb-2">{notification.message}</p>
                        <div className="text-xs text-text-secondary">
                          {formatTimeAgo(notification.time)}
                        </div>
                      </div>
                    </div>
                    {notification.actionRequired && (
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <i className="fas fa-bell-slash text-4xl text-gray-300 mb-4"></i>
              <p className="text-text-secondary">No notifications match your current filter</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}