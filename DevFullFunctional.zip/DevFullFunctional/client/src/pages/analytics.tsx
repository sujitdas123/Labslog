import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatsCard } from "@/components/stats-card";
import { Progress } from "@/components/ui/progress";
import type { Issue, LabUsageLog } from "@shared/schema";

export default function Analytics() {
  const { data: issues = [], isLoading: issuesLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: labLogs = [], isLoading: logsLoading } = useQuery<LabUsageLog[]>({
    queryKey: ["/api/lab-usage-logs"],
  });

  if (issuesLoading || logsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-text-secondary">Loading analytics...</div>
      </div>
    );
  }

  // Issue Analytics
  const totalIssues = issues.length;
  const openIssues = issues.filter(issue => issue.status === "open").length;
  const resolvedIssues = issues.filter(issue => issue.status === "resolved").length;
  const criticalIssues = issues.filter(issue => issue.priority === "Critical").length;
  
  const issuesByType = issues.reduce((acc, issue) => {
    acc[issue.issueType] = (acc[issue.issueType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const issuesByLab = issues.reduce((acc, issue) => {
    acc[issue.labNumber] = (acc[issue.labNumber] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Lab Usage Analytics
  const totalSessions = labLogs.length;
  const uniqueStudents = new Set(labLogs.map(log => log.rollNumber)).size;
  
  const usageByLab = labLogs.reduce((acc, log) => {
    acc[log.lab] = (acc[log.lab] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const usageByYear = labLogs.reduce((acc, log) => {
    acc[log.year] = (acc[log.year] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const resolutionRate = totalIssues > 0 ? (resolvedIssues / totalIssues) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Issues"
          value={totalIssues}
          icon="fas fa-exclamation-triangle"
          color="red"
        />
        <StatsCard
          title="Resolution Rate"
          value={`${resolutionRate.toFixed(1)}%`}
          icon="fas fa-check-circle"
          color="green"
        />
        <StatsCard
          title="Active Students"
          value={uniqueStudents}
          icon="fas fa-users"
          color="blue"
        />
        <StatsCard
          title="Lab Sessions"
          value={totalSessions}
          icon="fas fa-clipboard-list"
          color="yellow"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issues by Type */}
        <Card>
          <CardHeader>
            <CardTitle>Issues by Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(issuesByType).map(([type, count]) => (
                <div key={type} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{type}</span>
                  <div className="flex items-center space-x-2">
                    <Progress 
                      value={(count / totalIssues) * 100} 
                      className="w-20 h-2"
                    />
                    <span className="text-sm text-text-secondary">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Lab Usage Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Lab Usage Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(usageByLab).map(([lab, count]) => (
                <div key={lab} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{lab}</span>
                  <div className="flex items-center space-x-2">
                    <Progress 
                      value={(count / totalSessions) * 100} 
                      className="w-20 h-2"
                    />
                    <span className="text-sm text-text-secondary">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Issues by Lab */}
        <Card>
          <CardHeader>
            <CardTitle>Issues by Lab Location</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(issuesByLab).map(([lab, count]) => (
                <div key={lab} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{lab}</span>
                  <div className="flex items-center space-x-2">
                    <Progress 
                      value={(count / totalIssues) * 100} 
                      className="w-20 h-2"
                    />
                    <span className="text-sm text-text-secondary">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Student Year Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Usage by Student Year</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(usageByYear).map(([year, count]) => (
                <div key={year} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{year}</span>
                  <div className="flex items-center space-x-2">
                    <Progress 
                      value={(count / totalSessions) * 100} 
                      className="w-20 h-2"
                    />
                    <span className="text-sm text-text-secondary">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Lab Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600">{resolutionRate.toFixed(1)}%</div>
              <div className="text-sm text-green-700">Issue Resolution Rate</div>
            </div>
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="text-3xl font-bold text-blue-600">{(totalSessions / uniqueStudents).toFixed(1)}</div>
              <div className="text-sm text-blue-700">Avg Sessions per Student</div>
            </div>
            <div className="text-center p-6 bg-purple-50 rounded-lg">
              <div className="text-3xl font-bold text-purple-600">{criticalIssues}</div>
              <div className="text-sm text-purple-700">Critical Issues Pending</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}