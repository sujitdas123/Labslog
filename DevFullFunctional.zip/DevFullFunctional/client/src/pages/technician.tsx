import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatsCard } from "@/components/stats-card";
import { Modal } from "@/components/modal";
import { AdvancedSearch, type SearchFilters } from "@/components/advanced-search";
import { BulkActions, SelectableItem } from "@/components/bulk-actions";
import { ExportTools } from "@/components/export-tools";
import { apiRequest } from "@/lib/queryClient";
import type { Issue, LabUsageLog } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

export default function Technician() {
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [modalType, setModalType] = useState<"success" | "error">("success");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [priorityFilter, setPriorityFilter] = useState<string>("");
  const [selectedIssues, setSelectedIssues] = useState<number[]>([]);
  const [searchFilters, setSearchFilters] = useState<SearchFilters | null>(null);
  const [showExportTools, setShowExportTools] = useState(false);
  const { userRole } = useAuth();
  const queryClient = useQueryClient();

  const { data: issues = [], isLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: labUsage = [] } = useQuery<LabUsageLog[]>({
    queryKey: ["/api/lab-usage-logs"],
  });

  const updateIssueMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Issue> }) => {
      const response = await apiRequest("PATCH", `/api/issues/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
      setModalMessage("Issue updated successfully!");
      setModalType("success");
      setShowModal(true);
    },
    onError: (error) => {
      setModalMessage("Failed to update issue. Please try again.");
      setModalType("error");
      setShowModal(true);
    },
  });

  const deleteIssueMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/issues/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
      setModalMessage("Issue deleted successfully!");
      setModalType("success");
      setShowModal(true);
    },
    onError: (error) => {
      setModalMessage("Failed to delete issue. Please try again.");
      setModalType("error");
      setShowModal(true);
    },
  });

  if (userRole !== "technician") {
    return (
      <div className="text-center py-8">
        <p className="text-text-secondary">Access denied. Technician role required.</p>
      </div>
    );
  }

  const filteredIssues = issues.filter(issue => {
    const matchesStatus = !statusFilter || issue.status === statusFilter;
    const matchesPriority = !priorityFilter || issue.priority === priorityFilter;
    
    // Apply search filters if active
    if (searchFilters) {
      const matchesKeyword = !searchFilters.keyword || 
        issue.studentName.toLowerCase().includes(searchFilters.keyword.toLowerCase()) ||
        issue.description.toLowerCase().includes(searchFilters.keyword.toLowerCase()) ||
        issue.issueType.toLowerCase().includes(searchFilters.keyword.toLowerCase());
      
      const matchesSearchStatus = !searchFilters.status || issue.status === searchFilters.status;
      const matchesSearchPriority = !searchFilters.priority || issue.priority === searchFilters.priority;
      const matchesIssueType = !searchFilters.issueType || issue.issueType === searchFilters.issueType;
      const matchesLabNumber = !searchFilters.labNumber || issue.labNumber.includes(searchFilters.labNumber);
      const matchesStudentName = !searchFilters.studentName || 
        issue.studentName.toLowerCase().includes(searchFilters.studentName.toLowerCase());
      const matchesRollNumber = !searchFilters.rollNumber || 
        issue.rollNumber.toLowerCase().includes(searchFilters.rollNumber.toLowerCase());
      
      return matchesStatus && matchesPriority && matchesKeyword && matchesSearchStatus && 
             matchesSearchPriority && matchesIssueType && matchesLabNumber && matchesStudentName && matchesRollNumber;
    }
    
    return matchesStatus && matchesPriority;
  });

  const criticalIssues = issues.filter(issue => issue.priority === "Critical").length;
  const pendingIssues = issues.filter(issue => issue.status === "open").length;
  const resolvedToday = issues.filter(issue => 
    issue.status === "resolved" && 
    issue.updatedAt &&
    new Date(issue.updatedAt).toDateString() === new Date().toDateString()
  ).length;

  const handleResolve = (id: number) => {
    updateIssueMutation.mutate({ id, updates: { status: "resolved" } });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this issue?")) {
      deleteIssueMutation.mutate(id);
    }
  };

  const handleBulkAction = (action: string, selectedIds: number[]) => {
    selectedIds.forEach(id => {
      switch (action) {
        case "mark-resolved":
          updateIssueMutation.mutate({ id, updates: { status: "resolved" } });
          break;
        case "mark-in-progress":
          updateIssueMutation.mutate({ id, updates: { status: "in_progress" } });
          break;
        case "mark-open":
          updateIssueMutation.mutate({ id, updates: { status: "open" } });
          break;
        case "set-high-priority":
          updateIssueMutation.mutate({ id, updates: { priority: "High" } });
          break;
        case "set-medium-priority":
          updateIssueMutation.mutate({ id, updates: { priority: "Medium" } });
          break;
        case "set-low-priority":
          updateIssueMutation.mutate({ id, updates: { priority: "Low" } });
          break;
        case "delete-selected":
          deleteIssueMutation.mutate(id);
          break;
      }
    });
  };

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters);
  };

  const handleClearSearch = () => {
    setSearchFilters(null);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical": return "bg-red-100 text-red-800";
      case "High": return "bg-orange-100 text-orange-800";
      case "Medium": return "bg-yellow-100 text-yellow-800";
      case "Low": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-red-100 text-red-800";
      case "in_progress": return "bg-yellow-100 text-yellow-800";
      case "resolved": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Technician Dashboard */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Technician Dashboard</CardTitle>
              <p className="text-text-secondary">Manage and resolve reported issues</p>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                onClick={() => setShowExportTools(!showExportTools)}
              >
                <i className="fas fa-download mr-2"></i>
                Export Tools
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatsCard
              title="Critical Issues"
              value={criticalIssues}
              icon="fas fa-exclamation-circle"
              color="red"
            />
            <StatsCard
              title="Pending"
              value={pendingIssues}
              icon="fas fa-clock"
              color="yellow"
            />
            <StatsCard
              title="Resolved Today"
              value={resolvedToday}
              icon="fas fa-check-circle"
              color="green"
            />
            <StatsCard
              title="Total Issues"
              value={issues.length}
              icon="fas fa-list"
              color="blue"
            />
          </div>
        </CardContent>
      </Card>

      {/* Export Tools */}
      {showExportTools && (
        <ExportTools 
          data={{
            issues,
            labUsage
          }}
        />
      )}

      {/* Advanced Search */}
      <AdvancedSearch 
        onSearch={handleSearch}
        onClear={handleClearSearch}
      />

      {/* Bulk Actions */}
      <BulkActions
        selectedItems={selectedIssues}
        onSelectionChange={setSelectedIssues}
        items={filteredIssues}
        onBulkAction={handleBulkAction}
      />

      {/* Issues Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>All Issues</CardTitle>
            <div className="flex items-center space-x-3">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Status</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="All Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Priority</SelectItem>
                  <SelectItem value="Critical">Critical</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading issues...</div>
          ) : filteredIssues.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">Issue ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">Student</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">System</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">Issue Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">Priority</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredIssues.map((issue) => (
                    <SelectableItem
                      key={issue.id}
                      item={issue}
                      isSelected={selectedIssues.includes(issue.id)}
                      onSelectionChange={(selected) => {
                        if (selected) {
                          setSelectedIssues(prev => [...prev, issue.id]);
                        } else {
                          setSelectedIssues(prev => prev.filter(id => id !== issue.id));
                        }
                      }}
                    >
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                          ISS-{String(issue.id).padStart(3, '0')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-text-primary">{issue.studentName}</div>
                          <div className="text-sm text-text-secondary">{issue.rollNumber}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                          {issue.systemId} ({issue.labNumber})
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                          {issue.issueType}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(issue.priority)}`}>
                            {issue.priority}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(issue.status)}`}>
                            {issue.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                          {issue.status !== "resolved" && (
                            <Button
                              size="sm"
                              onClick={() => handleResolve(issue.id)}
                              disabled={updateIssueMutation.isPending}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              Resolve
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDelete(issue.id)}
                            disabled={deleteIssueMutation.isPending}
                          >
                            Delete
                          </Button>
                        </td>
                      </tr>
                    </SelectableItem>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-text-secondary">
              No issues found
            </div>
          )}
        </CardContent>
      </Card>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={modalType === "success" ? "Success!" : "Error"}
        type={modalType}
      >
        {modalMessage}
      </Modal>
    </div>
  );
}
