import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function StaffInfo() {
  const staffRoles = [
    {
      title: "Lab Technician",
      level: "Senior Level",
      description: "Manages overall lab operations and technical infrastructure",
      responsibilities: [
        "**System Administration:** Managing lab computer systems, networks, and software installations",
        "**Advanced Troubleshooting:** Diagnosing and resolving complex hardware and software issues",
        "**Equipment Maintenance:** Performing preventive maintenance and repairs on lab equipment",
        "**Security Management:** Implementing and maintaining lab security protocols and access controls",
        "**Training & Supervision:** Training technical assistants and student helpers",
        "**Budget Planning:** Assisting in equipment procurement and budget planning",
        "**Documentation:** Maintaining detailed technical documentation and procedures",
        "**Emergency Response:** Handling critical system failures and emergency situations"
      ],
      qualifications: [
        "Bachelor's degree in Computer Science, IT, or related field",
        "3+ years of experience in technical support or system administration",
        "Strong knowledge of computer hardware, software, and networking",
        "Experience with Windows, Linux, and macOS environments",
        "Certification in relevant technologies (CompTIA, Microsoft, Cisco, etc.)"
      ],
      skills: [
        "Hardware Troubleshooting",
        "Network Administration",
        "Software Installation",
        "System Security",
        "Project Management",
        "Technical Documentation"
      ],
      contact: "Sujit Das - Senior Lab Technician",
      email: "sujit.das@university.edu",
      phone: "+1-555-0123",
      location: "Main Lab Office (Room 101)"
    },
    {
      title: "Technical Assistant",
      level: "Entry to Mid Level",
      description: "Supports daily lab operations and provides first-level technical support",
      responsibilities: [
        "**Daily Operations:** Opening/closing labs, checking equipment status, and basic setup",
        "**First-Level Support:** Providing initial troubleshooting for common student issues",
        "**Equipment Monitoring:** Regular inspection and reporting of equipment condition",
        "**Student Assistance:** Helping students with basic technical questions and software usage",
        "**Inventory Management:** Tracking lab supplies, equipment, and software licenses",
        "**Cleaning & Organization:** Maintaining cleanliness and organization of lab spaces",
        "**Usage Logging:** Recording student lab usage and maintaining attendance logs",
        "**Incident Reporting:** Documenting and escalating issues to senior technicians"
      ],
      qualifications: [
        "Associate degree in Computer Science, IT, or equivalent experience",
        "1-2 years of technical support experience preferred",
        "Basic understanding of computer hardware and software",
        "Good communication skills for student interaction",
        "Ability to follow procedures and work independently"
      ],
      skills: [
        "Basic Troubleshooting",
        "Customer Service",
        "Equipment Maintenance",
        "Record Keeping",
        "Student Support",
        "Lab Organization"
      ],
      contact: "Technical Assistant Team",
      email: "tech.support@university.edu",
      phone: "+1-555-0124",
      location: "Lab Support Desk (Multiple Locations)"
    },
    {
      title: "Junior Technician",
      level: "Entry Level",
      description: "Entry-level technical support role focusing on basic troubleshooting and learning",
      responsibilities: [
        "**Basic System Support:** Performing routine system checks and basic troubleshooting under supervision",
        "**User Account Management:** Creating and managing student user accounts and access permissions",
        "**Software Installation:** Installing and updating standard software applications on lab computers",
        "**Hardware Replacement:** Replacing basic hardware components like keyboards, mice, and cables",
        "**Documentation Support:** Maintaining equipment logs and updating system documentation",
        "**Learning & Development:** Participating in training programs and skill development activities",
        "**Lab Preparation:** Setting up lab environments for classes and special sessions",
        "**Backup Support:** Assisting senior technicians with complex technical tasks"
      ],
      qualifications: [
        "High school diploma or equivalent, pursuing computer science/IT degree preferred",
        "Basic understanding of computer hardware and software",
        "Willingness to learn and follow technical procedures",
        "Good communication skills for student interaction",
        "Ability to work under supervision and follow detailed instructions"
      ],
      skills: [
        "Basic Computer Skills",
        "Hardware Identification",
        "Software Installation",
        "Customer Service",
        "Documentation",
        "Problem Solving"
      ],
      contact: "Junior Technician Program",
      email: "junior.tech@university.edu",
      phone: "+1-555-0125",
      location: "Training Lab (Room 105)"
    }
  ];

  const labProcedures = [
    {
      title: "Daily Lab Operations",
      procedures: [
        "**Morning Setup:** Power on all systems, check network connectivity, verify software functionality",
        "**Equipment Inspection:** Visual inspection of all hardware for damage or malfunction",
        "**Student Check-in:** Record student arrivals and system assignments",
        "**Issue Response:** Respond to student technical requests within 5 minutes",
        "**Evening Shutdown:** Proper system shutdown, security check, and lab closure"
      ]
    },
    {
      title: "Issue Resolution Workflow",
      procedures: [
        "**Initial Assessment:** Listen to student issue description and gather basic information",
        "**Basic Troubleshooting:** Attempt common solutions (restart, software reset, etc.)",
        "**Documentation:** Log issue in system with details, priority, and attempted solutions",
        "**Escalation:** If unresolved, escalate to senior technician with complete documentation",
        "**Follow-up:** Monitor resolution progress and update status in system"
      ]
    },
    {
      title: "Equipment Maintenance",
      procedures: [
        "**Weekly Cleaning:** Clean monitors, keyboards, mice, and work surfaces",
        "**Monthly Inspection:** Check cables, ports, and hardware components for wear",
        "**Software Updates:** Apply security patches and software updates during off-hours",
        "**Preventive Maintenance:** Schedule regular maintenance based on manufacturer recommendations",
        "**Replacement Planning:** Identify aging equipment and plan for replacements"
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-text-primary mb-4">Lab Staff Information</h1>
        <p className="text-text-secondary max-w-2xl mx-auto">
          Comprehensive guide to lab staff roles, responsibilities, and operational procedures
        </p>
      </div>

      {/* Staff Roles */}
      <div className="space-y-6">
        {staffRoles.map((role, index) => (
          <Card key={index} className="border-l-4 border-l-primary">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{role.title}</CardTitle>
                <Badge variant="secondary">{role.level}</Badge>
              </div>
              <p className="text-text-secondary">{role.description}</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-text-primary mb-3">Key Responsibilities</h4>
                  <ul className="space-y-2 text-sm text-text-secondary">
                    {role.responsibilities.map((resp, i) => (
                      <li key={i} className="flex items-start">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <span dangerouslySetInnerHTML={{ __html: resp }}></span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-text-primary mb-3">Required Qualifications</h4>
                    <ul className="space-y-1 text-sm text-text-secondary">
                      {role.qualifications.map((qual, i) => (
                        <li key={i} className="flex items-start">
                          <i className="fas fa-check text-green-500 mt-1 mr-2"></i>
                          <span>{qual}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-text-primary mb-3">Core Skills</h4>
                    <div className="flex flex-wrap gap-2">
                      {role.skills.map((skill, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold text-text-primary mb-2">Contact Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Name:</span> {role.contact}
                  </div>
                  <div>
                    <span className="font-medium">Email:</span> {role.email}
                  </div>
                  <div>
                    <span className="font-medium">Phone:</span> {role.phone}
                  </div>
                  <div className="md:col-span-3">
                    <span className="font-medium">Location:</span> {role.location}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Lab Procedures */}
      <Card>
        <CardHeader>
          <CardTitle>Standard Operating Procedures</CardTitle>
          <p className="text-text-secondary">
            Essential procedures for maintaining efficient lab operations
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {labProcedures.map((category, index) => (
              <div key={index} className="space-y-3">
                <h4 className="font-semibold text-text-primary">{category.title}</h4>
                <ul className="space-y-2 text-sm text-text-secondary">
                  {category.procedures.map((proc, i) => (
                    <li key={i} className="border-l-2 border-gray-200 pl-3">
                      <span dangerouslySetInnerHTML={{ __html: proc }}></span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Emergency Contacts */}
      <Card className="bg-red-50 border-red-200">
        <CardHeader>
          <CardTitle className="text-red-800">Emergency Contacts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold text-red-800 mb-2">Technical Emergencies</h4>
              <p><strong>Senior Technician:</strong> Sujit Das (+1-555-0123)</p>
              <p><strong>IT Support:</strong> +1-555-0199 (24/7)</p>
            </div>
            <div>
              <h4 className="font-semibold text-red-800 mb-2">Campus Security</h4>
              <p><strong>Security Office:</strong> +1-555-0911</p>
              <p><strong>Facilities:</strong> +1-555-0811</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}