import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Modal } from "@/components/modal";
import { apiRequest } from "@/lib/queryClient";
import { insertIssueSchema } from "@shared/schema";

const issueFormSchema = insertIssueSchema.extend({
  reportedBy: z.string().default("anonymous"),
  status: z.string().default("open"),
});

type IssueFormData = z.infer<typeof issueFormSchema>;

export default function IssueReport() {
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [modalType, setModalType] = useState<"success" | "error">("success");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<IssueFormData>({
    resolver: zodResolver(issueFormSchema),
    defaultValues: {
      studentName: "",
      rollNumber: "",
      labNumber: "",
      systemId: "",
      issueType: "",
      priority: "",
      description: "",
      reportedBy: "anonymous",
      status: "open",
    },
  });

  const createIssueMutation = useMutation({
    mutationFn: async (data: IssueFormData) => {
      const response = await apiRequest("POST", "/api/issues", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
      setModalMessage("Issue reported successfully!");
      setModalType("success");
      setShowModal(true);
      form.reset();
    },
    onError: (error) => {
      setModalMessage("Failed to report issue. Please try again.");
      setModalType("error");
      setShowModal(true);
    },
  });

  const onSubmit = (data: IssueFormData) => {
    createIssueMutation.mutate(data);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Report New Issue</CardTitle>
          <p className="text-text-secondary">
            Please provide detailed information about the issue you're experiencing
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="studentName">Student Name</Label>
                <Input
                  id="studentName"
                  {...form.register("studentName")}
                  className="mt-1"
                />
                {form.formState.errors.studentName && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.studentName.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="rollNumber">Roll Number</Label>
                <Input
                  id="rollNumber"
                  {...form.register("rollNumber")}
                  className="mt-1"
                />
                {form.formState.errors.rollNumber && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.rollNumber.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="labNumber">Lab Number</Label>
                <Select onValueChange={(value) => form.setValue("labNumber", value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select Lab" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PL-1">PL-1</SelectItem>
                    <SelectItem value="PL-2">PL-2</SelectItem>
                    <SelectItem value="PL-3">PL-3</SelectItem>
                    <SelectItem value="PL-4">PL-4</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.labNumber && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.labNumber.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="systemId">System ID</Label>
                <Input
                  id="systemId"
                  {...form.register("systemId")}
                  placeholder="e.g., PC-15"
                  className="mt-1"
                />
                {form.formState.errors.systemId && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.systemId.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="issueType">Issue Type</Label>
                <Select onValueChange={(value) => form.setValue("issueType", value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select Issue Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Hardware">Hardware Issue</SelectItem>
                    <SelectItem value="Software">Software Issue</SelectItem>
                    <SelectItem value="Network">Network Issue</SelectItem>
                    <SelectItem value="Power">Power Issue</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.issueType && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.issueType.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select onValueChange={(value) => form.setValue("priority", value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Critical">Critical</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.priority && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.priority.message}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                {...form.register("description")}
                rows={4}
                placeholder="Please describe the issue in detail..."
                className="mt-1"
              />
              {form.formState.errors.description && (
                <p className="text-sm text-red-600 mt-1">
                  {form.formState.errors.description.message}
                </p>
              )}
            </div>

            <div className="flex items-center justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => form.reset()}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createIssueMutation.isPending}
                className="bg-primary text-white hover:bg-primary-dark"
              >
                {createIssueMutation.isPending ? "Submitting..." : "Submit Issue"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={modalType === "success" ? "Success!" : "Error"}
        type={modalType}
      >
        {modalMessage}
      </Modal>
    </div>
  );
}
