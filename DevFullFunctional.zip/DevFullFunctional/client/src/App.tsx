import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/sidebar";
import { WelcomeScreen } from "@/components/welcome-screen";
import { useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Dashboard from "@/pages/dashboard";
import IssueReport from "@/pages/issue-report";
import LabUsage from "@/pages/lab-usage";
import Technician from "@/pages/technician";
import Analytics from "@/pages/analytics";
import Notifications from "@/pages/notifications";
import Settings from "@/pages/settings";
import StaffInfo from "@/pages/staff-info";
import SystemMonitoring from "@/pages/system-monitoring";
import NotFound from "@/pages/not-found";
import type { Issue } from "@shared/schema";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/issue-report" component={IssueReport} />
      <Route path="/lab-usage" component={LabUsage} />
      <Route path="/technician" component={Technician} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/settings" component={Settings} />
      <Route path="/staff-info" component={StaffInfo} />
      <Route path="/system-monitoring" component={SystemMonitoring} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { user, loading, signIn } = useAuth();
  const [showWelcome, setShowWelcome] = useState(true);

  // Get notification count from open issues
  const { data: issues = [] } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const openIssuesCount = issues.filter(issue => issue.status === "open").length;

  useEffect(() => {
    if (!loading && !user) {
      signIn();
    }
  }, [loading, user, signIn]);

  if (loading) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="text-text-secondary">Loading...</div>
      </div>
    );
  }

  if (showWelcome) {
    return <WelcomeScreen onContinue={() => setShowWelcome(false)} />;
  }

  return (
    <div className="min-h-screen bg-surface">
      <div className="flex">
        <Sidebar />
        <div className="flex-1 lg:ml-64">
          {/* Header */}
          <header className="bg-white shadow-sm border-b border-gray-200">
            <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-text-primary">Programming Lab Management</h1>
                  <p className="text-text-secondary">Manage lab resources and track issues efficiently</p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <button className="p-2 text-text-secondary hover:text-primary relative">
                      <i className="fas fa-bell text-lg"></i>
                      {openIssuesCount > 0 && (
                        <span className="absolute -top-1 -right-1 bg-error text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                          {openIssuesCount}
                        </span>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <Router />
          </main>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
