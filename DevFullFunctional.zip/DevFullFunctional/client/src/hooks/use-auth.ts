import { useState, useEffect } from "react";
import { auth } from "@/lib/firebase";
import { onAuthStateChanged, signInAnonymously, User } from "firebase/auth";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [userRole, setUserRole] = useState<"student" | "technician">("student");

  useEffect(() => {
    // If Firebase is not initialized, create a demo user
    if (!auth) {
      const demoUser = {
        uid: "demo-user-" + Date.now(),
        displayName: "Demo User",
        email: "demo@lab.local",
        isAnonymous: true
      } as User;
      
      setUser(demoUser);
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const signIn = async () => {
    try {
      if (auth) {
        await signInAnonymously(auth);
      } else {
        // Demo mode - already handled in useEffect
        console.log("Running in demo mode without Firebase");
      }
    } catch (error) {
      console.error("Sign in failed:", error);
      // Fallback to demo mode if Firebase fails
      const demoUser = {
        uid: "demo-user-" + Date.now(),
        displayName: "Demo User",
        email: "demo@lab.local",
        isAnonymous: true
      } as User;
      
      setUser(demoUser);
      setLoading(false);
    }
  };

  const toggleRole = () => {
    setUserRole(prev => prev === "student" ? "technician" : "student");
  };

  return { user, loading, userRole, signIn, toggleRole };
}
