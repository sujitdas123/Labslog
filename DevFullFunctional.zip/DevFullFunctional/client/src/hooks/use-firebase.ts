import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc } from "firebase/firestore";
import type { Issue, LabUsageLog } from "@shared/schema";

export function useFirebaseIssues() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "issues"), (snapshot) => {
      const issuesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Issue[];
      setIssues(issuesData);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const addIssue = async (issueData: Omit<Issue, "id">) => {
    try {
      await addDoc(collection(db, "issues"), issueData);
    } catch (error) {
      console.error("Error adding issue:", error);
      throw error;
    }
  };

  const updateIssue = async (id: string, updates: Partial<Issue>) => {
    try {
      await updateDoc(doc(db, "issues", id), updates);
    } catch (error) {
      console.error("Error updating issue:", error);
      throw error;
    }
  };

  const deleteIssue = async (id: string) => {
    try {
      await deleteDoc(doc(db, "issues", id));
    } catch (error) {
      console.error("Error deleting issue:", error);
      throw error;
    }
  };

  return { issues, loading, addIssue, updateIssue, deleteIssue };
}

export function useFirebaseLabUsage() {
  const [logs, setLogs] = useState<LabUsageLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "labUsageLogs"), (snapshot) => {
      const logsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as LabUsageLog[];
      setLogs(logsData);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const addLog = async (logData: Omit<LabUsageLog, "id">) => {
    try {
      await addDoc(collection(db, "labUsageLogs"), logData);
    } catch (error) {
      console.error("Error adding lab usage log:", error);
      throw error;
    }
  };

  const deleteLog = async (id: string) => {
    try {
      await deleteDoc(doc(db, "labUsageLogs", id));
    } catch (error) {
      console.error("Error deleting lab usage log:", error);
      throw error;
    }
  };

  return { logs, loading, addLog, deleteLog };
}
