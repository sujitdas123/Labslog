import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface AdvancedSearchProps {
  onSearch: (filters: SearchFilters) => void;
  onClear: () => void;
}

export interface SearchFilters {
  keyword: string;
  status: string;
  priority: string;
  issueType: string;
  labNumber: string;
  dateRange: {
    from: Date | null;
    to: Date | null;
  };
  studentName: string;
  rollNumber: string;
}

export function AdvancedSearch({ onSearch, onClear }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    keyword: "",
    status: "",
    priority: "",
    issueType: "",
    labNumber: "",
    dateRange: { from: null, to: null },
    studentName: "",
    rollNumber: ""
  });

  const [isExpanded, setIsExpanded] = useState(false);

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSearch = () => {
    onSearch(filters);
  };

  const handleClear = () => {
    setFilters({
      keyword: "",
      status: "",
      priority: "",
      issueType: "",
      labNumber: "",
      dateRange: { from: null, to: null },
      studentName: "",
      rollNumber: ""
    });
    onClear();
  };

  const activeFiltersCount = Object.values(filters).filter(value => {
    if (typeof value === 'string') return value.length > 0;
    if (typeof value === 'object' && value !== null) {
      return Object.values(value).some(v => v !== null);
    }
    return false;
  }).length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-search text-primary"></i>
            <span>Advanced Search</span>
            {activeFiltersCount > 0 && (
              <Badge variant="secondary">{activeFiltersCount} active</Badge>
            )}
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <i className={`fas fa-chevron-${isExpanded ? 'up' : 'down'}`}></i>
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Quick Search */}
        <div className="flex space-x-2">
          <Input
            placeholder="Search by keyword, issue description, or student name..."
            value={filters.keyword}
            onChange={(e) => updateFilter("keyword", e.target.value)}
            className="flex-1"
          />
          <Button onClick={handleSearch} className="bg-primary hover:bg-primary-dark">
            <i className="fas fa-search mr-2"></i>
            Search
          </Button>
          <Button variant="outline" onClick={handleClear}>
            <i className="fas fa-times mr-2"></i>
            Clear
          </Button>
        </div>

        {/* Advanced Filters */}
        {isExpanded && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t">
            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={filters.status} onValueChange={(value) => updateFilter("status", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All statuses</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="priority">Priority</Label>
              <Select value={filters.priority} onValueChange={(value) => updateFilter("priority", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="All priorities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All priorities</SelectItem>
                  <SelectItem value="Critical">Critical</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="issue-type">Issue Type</Label>
              <Select value={filters.issueType} onValueChange={(value) => updateFilter("issueType", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All types</SelectItem>
                  <SelectItem value="Hardware">Hardware</SelectItem>
                  <SelectItem value="Software">Software</SelectItem>
                  <SelectItem value="Network">Network</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="lab-number">Lab Number</Label>
              <Input
                id="lab-number"
                placeholder="e.g., Lab 1, Lab 2A"
                value={filters.labNumber}
                onChange={(e) => updateFilter("labNumber", e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="student-name">Student Name</Label>
              <Input
                id="student-name"
                placeholder="Student name"
                value={filters.studentName}
                onChange={(e) => updateFilter("studentName", e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="roll-number">Roll Number</Label>
              <Input
                id="roll-number"
                placeholder="e.g., CS2023001"
                value={filters.rollNumber}
                onChange={(e) => updateFilter("rollNumber", e.target.value)}
              />
            </div>

            <div className="md:col-span-2">
              <Label>Date Range</Label>
              <div className="flex space-x-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="flex-1">
                      <i className="fas fa-calendar mr-2"></i>
                      {filters.dateRange.from ? format(filters.dateRange.from, "PPP") : "From date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={filters.dateRange.from}
                      onSelect={(date) => updateFilter("dateRange", { ...filters.dateRange, from: date })}
                    />
                  </PopoverContent>
                </Popover>
                
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="flex-1">
                      <i className="fas fa-calendar mr-2"></i>
                      {filters.dateRange.to ? format(filters.dateRange.to, "PPP") : "To date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={filters.dateRange.to}
                      onSelect={(date) => updateFilter("dateRange", { ...filters.dateRange, to: date })}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
        )}

        {/* Active Filters Display */}
        {activeFiltersCount > 0 && (
          <div className="flex flex-wrap gap-2 pt-2 border-t">
            {filters.keyword && (
              <Badge variant="outline" className="flex items-center space-x-1">
                <span>Keyword: {filters.keyword}</span>
                <button
                  onClick={() => updateFilter("keyword", "")}
                  className="ml-1 text-xs hover:text-destructive"
                >
                  <i className="fas fa-times"></i>
                </button>
              </Badge>
            )}
            {filters.status && (
              <Badge variant="outline" className="flex items-center space-x-1">
                <span>Status: {filters.status}</span>
                <button
                  onClick={() => updateFilter("status", "")}
                  className="ml-1 text-xs hover:text-destructive"
                >
                  <i className="fas fa-times"></i>
                </button>
              </Badge>
            )}
            {filters.priority && (
              <Badge variant="outline" className="flex items-center space-x-1">
                <span>Priority: {filters.priority}</span>
                <button
                  onClick={() => updateFilter("priority", "")}
                  className="ml-1 text-xs hover:text-destructive"
                >
                  <i className="fas fa-times"></i>
                </button>
              </Badge>
            )}
            {filters.issueType && (
              <Badge variant="outline" className="flex items-center space-x-1">
                <span>Type: {filters.issueType}</span>
                <button
                  onClick={() => updateFilter("issueType", "")}
                  className="ml-1 text-xs hover:text-destructive"
                >
                  <i className="fas fa-times"></i>
                </button>
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}