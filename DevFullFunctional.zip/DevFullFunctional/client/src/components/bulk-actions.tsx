import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import type { Issue } from "@shared/schema";

interface BulkActionsProps {
  selectedItems: number[];
  onSelectionChange: (selectedIds: number[]) => void;
  items: Issue[];
  onBulkAction: (action: string, selectedIds: number[]) => void;
}

export function BulkActions({ selectedItems, onSelectionChange, items, onBulkAction }: BulkActionsProps) {
  const [bulkAction, setBulkAction] = useState<string>("");
  const { toast } = useToast();

  const handleSelectAll = () => {
    if (selectedItems.length === items.length) {
      onSelectionChange([]);
    } else {
      onSelectionChange(items.map(item => item.id));
    }
  };

  const handleBulkAction = () => {
    if (!bulkAction || selectedItems.length === 0) {
      toast({
        title: "Invalid Action",
        description: "Please select items and choose an action.",
        variant: "destructive"
      });
      return;
    }

    onBulkAction(bulkAction, selectedItems);
    setBulkAction("");
    onSelectionChange([]);
  };

  const isAllSelected = selectedItems.length === items.length && items.length > 0;
  const isPartialSelected = selectedItems.length > 0 && selectedItems.length < items.length;

  if (items.length === 0) return null;

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                checked={isAllSelected}
                ref={(el) => {
                  if (el) el.indeterminate = isPartialSelected;
                }}
                onCheckedChange={handleSelectAll}
              />
              <span className="text-sm font-medium">
                Select All ({selectedItems.length} of {items.length})
              </span>
            </div>

            {selectedItems.length > 0 && (
              <Badge variant="secondary" className="bg-primary text-primary-foreground">
                {selectedItems.length} selected
              </Badge>
            )}
          </div>

          {selectedItems.length > 0 && (
            <div className="flex items-center space-x-2">
              <Select value={bulkAction} onValueChange={setBulkAction}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Choose action..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mark-resolved">Mark as Resolved</SelectItem>
                  <SelectItem value="mark-in-progress">Mark as In Progress</SelectItem>
                  <SelectItem value="mark-open">Mark as Open</SelectItem>
                  <SelectItem value="set-high-priority">Set High Priority</SelectItem>
                  <SelectItem value="set-medium-priority">Set Medium Priority</SelectItem>
                  <SelectItem value="set-low-priority">Set Low Priority</SelectItem>
                  <SelectItem value="assign-to-me">Assign to Me</SelectItem>
                  <SelectItem value="export-selected">Export Selected</SelectItem>
                  <SelectItem value="delete-selected">Delete Selected</SelectItem>
                </SelectContent>
              </Select>

              <Button
                onClick={handleBulkAction}
                disabled={!bulkAction}
                className="bg-primary hover:bg-primary-dark"
              >
                <i className="fas fa-check mr-2"></i>
                Apply Action
              </Button>
            </div>
          )}
        </div>

        {selectedItems.length > 0 && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-2">
              <i className="fas fa-info-circle text-blue-600"></i>
              <span className="text-sm text-blue-800">
                Actions will be applied to {selectedItems.length} selected item{selectedItems.length > 1 ? 's' : ''}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface SelectableItemProps {
  item: Issue;
  isSelected: boolean;
  onSelectionChange: (selected: boolean) => void;
  children: React.ReactNode;
}

export function SelectableItem({ item, isSelected, onSelectionChange, children }: SelectableItemProps) {
  return (
    <div className={`relative ${isSelected ? 'ring-2 ring-primary ring-offset-2' : ''}`}>
      <div className="absolute left-2 top-2 z-10">
        <Checkbox
          checked={isSelected}
          onCheckedChange={onSelectionChange}
          className="bg-white"
        />
      </div>
      <div className={`pl-8 ${isSelected ? 'bg-primary/5' : ''}`}>
        {children}
      </div>
    </div>
  );
}