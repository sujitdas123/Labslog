import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import type { Issue, LabUsageLog } from "@shared/schema";

interface ExportToolsProps {
  data: {
    issues: Issue[];
    labUsage: LabUsageLog[];
  };
}

export function ExportTools({ data }: ExportToolsProps) {
  const [exportType, setExportType] = useState<string>("issues");
  const [format, setFormat] = useState<string>("csv");
  const [dateRange, setDateRange] = useState<string>("all");
  const [includeResolved, setIncludeResolved] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  
  const { toast } = useToast();

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      let exportData: any[] = [];
      
      // Filter data based on selections
      if (exportType === "issues") {
        exportData = data.issues.filter(issue => {
          if (!includeResolved && issue.status === "resolved") return false;
          return true;
        });
      } else if (exportType === "lab-usage") {
        exportData = data.labUsage;
      } else if (exportType === "combined") {
        exportData = {
          issues: data.issues,
          labUsage: data.labUsage
        };
      }

      // Apply date filtering
      if (dateRange !== "all") {
        const now = new Date();
        const filterDate = new Date();
        
        switch (dateRange) {
          case "last-7-days":
            filterDate.setDate(now.getDate() - 7);
            break;
          case "last-30-days":
            filterDate.setDate(now.getDate() - 30);
            break;
          case "last-90-days":
            filterDate.setDate(now.getDate() - 90);
            break;
        }

        if (Array.isArray(exportData)) {
          exportData = exportData.filter(item => {
            const itemDate = new Date(item.createdAt || item.sessionDate);
            return itemDate >= filterDate;
          });
        }
      }

      // Generate file content
      let content = "";
      let filename = "";
      
      if (format === "csv") {
        content = generateCSV(exportData, exportType);
        filename = `${exportType}-export-${new Date().toISOString().split('T')[0]}.csv`;
      } else if (format === "json") {
        content = JSON.stringify(exportData, null, 2);
        filename = `${exportType}-export-${new Date().toISOString().split('T')[0]}.json`;
      }

      // Download file
      const blob = new Blob([content], { type: format === "csv" ? "text/csv" : "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: `${exportType} data has been exported successfully.`,
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data.",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const generateCSV = (data: any[], type: string) => {
    if (type === "issues") {
      const headers = [
        "ID", "Student Name", "Roll Number", "Issue Type", "Priority", 
        "Status", "Lab Number", "System ID", "Description", "Created At"
      ];
      
      const rows = data.map(issue => [
        issue.id,
        issue.studentName,
        issue.rollNumber,
        issue.issueType,
        issue.priority,
        issue.status,
        issue.labNumber,
        issue.systemId,
        `"${issue.description}"`,
        new Date(issue.createdAt).toLocaleDateString()
      ]);
      
      return [headers, ...rows].map(row => row.join(",")).join("\n");
    } else if (type === "lab-usage") {
      const headers = [
        "ID", "Student Name", "Roll Number", "Year", "Subject", 
        "Lab", "Session Date", "Start Time", "End Time", "Purpose"
      ];
      
      const rows = data.map(log => [
        log.id,
        log.studentName,
        log.rollNumber,
        log.year,
        log.subject,
        log.lab,
        new Date(log.sessionDate).toLocaleDateString(),
        log.startTime,
        log.endTime,
        `"${log.purpose}"`
      ]);
      
      return [headers, ...rows].map(row => row.join(",")).join("\n");
    }
    
    return "";
  };

  const getExportCount = () => {
    if (exportType === "issues") {
      return includeResolved ? data.issues.length : data.issues.filter(i => i.status !== "resolved").length;
    } else if (exportType === "lab-usage") {
      return data.labUsage.length;
    }
    return data.issues.length + data.labUsage.length;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fas fa-download text-primary"></i>
          <span>Export Data</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="export-type">Data Type</Label>
            <Select value={exportType} onValueChange={setExportType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="issues">Issues Only</SelectItem>
                <SelectItem value="lab-usage">Lab Usage Only</SelectItem>
                <SelectItem value="combined">Combined Report</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="format">Format</Label>
            <Select value={format} onValueChange={setFormat}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV (Excel Compatible)</SelectItem>
                <SelectItem value="json">JSON</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="date-range">Date Range</Label>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="last-7-days">Last 7 Days</SelectItem>
                <SelectItem value="last-30-days">Last 30 Days</SelectItem>
                <SelectItem value="last-90-days">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {exportType === "issues" && (
            <div className="flex items-center space-x-2">
              <Checkbox
                id="include-resolved"
                checked={includeResolved}
                onCheckedChange={setIncludeResolved}
              />
              <Label htmlFor="include-resolved">Include Resolved Issues</Label>
            </div>
          )}
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-text-primary">Export Summary</h4>
              <p className="text-sm text-text-secondary">
                {getExportCount()} records will be exported in {format.toUpperCase()} format
              </p>
            </div>
            <Button
              onClick={handleExport}
              disabled={isExporting}
              className="bg-primary hover:bg-primary-dark"
            >
              {isExporting ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Exporting...
                </>
              ) : (
                <>
                  <i className="fas fa-download mr-2"></i>
                  Export Data
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="text-xs text-text-secondary">
          <p>• CSV files can be opened directly in Excel or Google Sheets</p>
          <p>• JSON files are suitable for programmatic processing</p>
          <p>• All personal data is included as per your selection</p>
        </div>
      </CardContent>
    </Card>
  );
}