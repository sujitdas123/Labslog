import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export function Sidebar() {
  const [location] = useLocation();
  const { userRole, user, toggleRole } = useAuth();

  const navigation = [
    { name: 'Dashboard', href: '/', icon: 'fas fa-tachometer-alt' },
    { name: 'Report Issue', href: '/issue-report', icon: 'fas fa-exclamation-triangle' },
    { name: 'Lab Usage', href: '/lab-usage', icon: 'fas fa-clipboard-list' },
    { name: 'Notifications', href: '/notifications', icon: 'fas fa-bell' },
    { name: 'Analytics', href: '/analytics', icon: 'fas fa-chart-bar' },
    ...(userRole === 'technician' ? [
      { name: 'Technician Panel', href: '/technician', icon: 'fas fa-tools' },
      { name: 'Staff Info', href: '/staff-info', icon: 'fas fa-users-cog' },
      { name: 'System Monitor', href: '/system-monitoring', icon: 'fas fa-server' }
    ] : []),
    { name: 'Settings', href: '/settings', icon: 'fas fa-cog' },
  ];

  return (
    <nav className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform -translate-x-full transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0">
      <div className="flex items-center justify-center h-16 bg-primary text-white">
        <i className="fas fa-flask mr-3"></i>
        <span className="text-xl font-semibold">Lab Manager</span>
      </div>
      <div className="mt-8">
        <nav className="px-4 space-y-2">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                location === item.href
                  ? 'bg-blue-50 text-primary'
                  : 'text-text-secondary hover:bg-gray-50'
              }`}
            >
              <i className={`${item.icon} mr-3`}></i>
              {item.name}
            </Link>
          ))}
        </nav>
      </div>
      <div className="absolute bottom-0 w-full p-4 bg-gray-50">
        <div className="flex items-center mb-4">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-semibold">
            <span>{userRole === 'student' ? 'S' : 'T'}</span>
          </div>
          <div className="ml-3">
            <div className="text-sm font-medium text-text-primary">
              {userRole === 'student' ? 'Student User' : 'Technician'}
            </div>
            <div className="text-xs text-text-secondary capitalize">{userRole}</div>
          </div>
        </div>
        <button
          onClick={toggleRole}
          className="w-full px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors text-sm"
        >
          Switch to {userRole === 'student' ? 'Technician' : 'Student'}
        </button>
      </div>
    </nav>
  );
}
