interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  color: "red" | "green" | "blue" | "yellow";
}

export function StatsCard({ title, value, icon, color }: StatsCardProps) {
  const getColorStyles = () => {
    switch (color) {
      case "red":
        return {
          bg: "bg-red-50",
          iconBg: "bg-red-100",
          iconColor: "text-red-600",
          textColor: "text-red-600"
        };
      case "green":
        return {
          bg: "bg-green-50",
          iconBg: "bg-green-100",
          iconColor: "text-green-600",
          textColor: "text-green-600"
        };
      case "blue":
        return {
          bg: "bg-blue-50",
          iconBg: "bg-blue-100",
          iconColor: "text-blue-600",
          textColor: "text-blue-600"
        };
      case "yellow":
        return {
          bg: "bg-yellow-50",
          iconBg: "bg-yellow-100",
          iconColor: "text-yellow-600",
          textColor: "text-yellow-600"
        };
      default:
        return {
          bg: "bg-gray-50",
          iconBg: "bg-gray-100",
          iconColor: "text-gray-600",
          textColor: "text-gray-600"
        };
    }
  };

  const styles = getColorStyles();

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
      <div className="flex items-center">
        <div className="flex-shrink-0">
          <div className={`w-8 h-8 ${styles.iconBg} rounded-lg flex items-center justify-center`}>
            <i className={`${icon} ${styles.iconColor}`}></i>
          </div>
        </div>
        <div className="ml-4">
          <div className="text-2xl font-bold text-text-primary">{value}</div>
          <div className="text-sm text-text-secondary">{title}</div>
        </div>
      </div>
    </div>
  );
}
