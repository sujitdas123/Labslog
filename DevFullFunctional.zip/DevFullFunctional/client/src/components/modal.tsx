import { ReactNode } from "react";
import { Button } from "@/components/ui/button";

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  type?: "success" | "error" | "info";
}

export function Modal({ isOpen, onClose, title, children, type = "info" }: ModalProps) {
  if (!isOpen) return null;

  const getTypeStyles = () => {
    switch (type) {
      case "success":
        return {
          iconBg: "bg-green-100",
          icon: "fas fa-check text-green-600",
          buttonBg: "bg-green-600 hover:bg-green-700"
        };
      case "error":
        return {
          iconBg: "bg-red-100",
          icon: "fas fa-exclamation-triangle text-red-600",
          buttonBg: "bg-red-600 hover:bg-red-700"
        };
      default:
        return {
          iconBg: "bg-blue-100",
          icon: "fas fa-info-circle text-blue-600",
          buttonBg: "bg-primary hover:bg-primary-dark"
        };
    }
  };

  const styles = getTypeStyles();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md mx-4">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 ${styles.iconBg} rounded-full flex items-center justify-center mr-4`}>
            <i className={`${styles.icon} text-xl`}></i>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">{title}</h3>
            <div className="text-text-secondary">{children}</div>
          </div>
        </div>
        <div className="flex justify-end">
          <Button
            onClick={onClose}
            className={`px-4 py-2 text-white rounded-lg transition-colors ${styles.buttonBg}`}
          >
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
