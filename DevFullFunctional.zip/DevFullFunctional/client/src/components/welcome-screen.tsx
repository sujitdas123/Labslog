import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";

interface WelcomeScreenProps {
  onContinue: () => void;
}

export function WelcomeScreen({ onContinue }: WelcomeScreenProps) {
  const { userRole, toggleRole } = useAuth();

  const handleContinue = () => {
    onContinue();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full mx-auto">
        <div className="text-center mb-12">
          <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-flask text-white text-3xl"></i>
          </div>
          <h1 className="text-4xl font-bold text-text-primary mb-4">
            Programming Lab Management System
          </h1>
          <p className="text-xl text-text-secondary max-w-2xl mx-auto">
            A comprehensive solution for managing lab resources, tracking issues, and maintaining usage logs efficiently.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Student Features */}
          <Card className="border-2 border-blue-200 hover:border-blue-300 transition-colors">
            <CardHeader>
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-user-graduate text-blue-600 text-2xl"></i>
              </div>
              <CardTitle className="text-center text-blue-800">Student Portal</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-text-secondary">
                <li className="flex items-center">
                  <i className="fas fa-exclamation-triangle text-red-500 mr-3"></i>
                  Report technical issues
                </li>
                <li className="flex items-center">
                  <i className="fas fa-clipboard-list text-green-500 mr-3"></i>
                  Log lab usage sessions
                </li>
                <li className="flex items-center">
                  <i className="fas fa-chart-bar text-purple-500 mr-3"></i>
                  View personal statistics
                </li>
                <li className="flex items-center">
                  <i className="fas fa-history text-orange-500 mr-3"></i>
                  Track issue history
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Technician Features */}
          <Card className="border-2 border-purple-200 hover:border-purple-300 transition-colors">
            <CardHeader>
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-tools text-purple-600 text-2xl"></i>
              </div>
              <CardTitle className="text-center text-purple-800">Technician Panel</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-text-secondary">
                <li className="flex items-center">
                  <i className="fas fa-tasks text-blue-500 mr-3"></i>
                  Manage all reported issues
                </li>
                <li className="flex items-center">
                  <i className="fas fa-filter text-green-500 mr-3"></i>
                  Filter by priority and status
                </li>
                <li className="flex items-center">
                  <i className="fas fa-check-circle text-purple-500 mr-3"></i>
                  Update issue status
                </li>
                <li className="flex items-center">
                  <i className="fas fa-download text-orange-500 mr-3"></i>
                  Export usage reports
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md mx-auto">
            <h3 className="text-lg font-semibold text-text-primary mb-4">
              Select Your Role
            </h3>
            <div className="flex items-center justify-center space-x-4 mb-6">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${userRole === 'student' ? 'bg-blue-500' : 'bg-gray-300'}`}></div>
                <span className={`text-sm ${userRole === 'student' ? 'text-blue-600 font-medium' : 'text-text-secondary'}`}>
                  Student
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${userRole === 'technician' ? 'bg-purple-500' : 'bg-gray-300'}`}></div>
                <span className={`text-sm ${userRole === 'technician' ? 'text-purple-600 font-medium' : 'text-text-secondary'}`}>
                  Technician
                </span>
              </div>
            </div>
            <div className="flex space-x-3">
              <Button
                onClick={toggleRole}
                variant="outline"
                className="flex-1"
              >
                Switch to {userRole === 'student' ? 'Technician' : 'Student'}
              </Button>
              <Button
                onClick={handleContinue}
                className="flex-1 bg-primary hover:bg-primary-dark"
              >
                Continue as {userRole === 'student' ? 'Student' : 'Technician'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}